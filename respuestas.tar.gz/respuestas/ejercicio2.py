'''
Crea un program en python que haga lo siguiente:
Pregunte por un directorio. Si se quiere listar el directorio actual no se introduce nada
El programa debe reportar cuando el directorio no es correcto por fallo del usuario.
No vale contar ni '.' ni '..' que son el directorio actual y el padre.
'''

import os
import subprocess

directorio = input("Introduce el directorio(intro para actual): ")
if directorio == '':
    comando = ["ls", "-a"]
else:    
    comando = ["ls", "-a", directorio]
#hola radiola
proceso = subprocess.Popen(comando,
                   stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE,
                   text=True)

noError=True
for linea in proceso.stderr:
    print(linea)
    noError=False

if noError:
    cont=0
    for linea in proceso.stdout:
        if not linea == ".\n" and not linea== "..\n" and linea[0] == ".":
            cont+=1

    print(f"El número de fichero ocultos en ese directorio es: {cont}")
