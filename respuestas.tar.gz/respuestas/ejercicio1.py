'''
Crea un programa en Python que:

- Pida al usuario un número N (cantidad de procesos hijos a crear).

- Use os.fork() para crear N procesos hijos.

 -Cada hijo debe imprimir:

    Su número de proceso (PID).

    El número de orden en el que se cre (1<=numero<=N).

    Una pausa aleatoria entre impresiones (para simular trabajo), entre 1 y 2 minutos.
'''

import os
import time
import random

hijos = int(input("introduce el número de hijos: "))

#Creamos los hijos.
for numHijo in range(hijos):
    pid = os.fork()

    if pid==0:
        print(f"Hijo {numHijo+1} creado con el número de proceso {os.getpid()}.")
        time.sleep(random.randrange(1,2))
        print(f"Proceso {os.getpid()} finalizado")
        os._exit(0)

